package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@JsonClass(generateAdapter = true)
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@JsonClass(generateAdapter = true)
data class Part(
    val text: String? = null,
    @Json(name = "inline_data") val inlineData: InlineData? = null
)

@JsonClass(generateAdapter = true)
data class InlineData(
    @Json(name = "mime_type") val mimeType: String,
    val data: String
)

@JsonClass(generateAdapter = true)
data class GenerationConfig(
    val temperature: Float? = null,
    val topP: Float? = null,
    val topK: Int? = null
)

@JsonClass(generateAdapter = true)
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null,
    val error: ApiError? = null
)

@JsonClass(generateAdapter = true)
data class Candidate(
    val content: Content? = null,
    val finishReason: String? = null
)

@JsonClass(generateAdapter = true)
data class ApiError(
    val code: Int? = null,
    val message: String? = null,
    val status: String? = null
)

enum class AiPersona(
    val id: String,
    val displayName: String,
    val titleHindi: String,
    val iconName: String,
    val description: String,
    val systemPrompt: String
) {
    MINT_ANIME(
        id = "mint_anime",
        displayName = "Mint (3D Anime Companion)",
        titleHindi = "मिंट (3D एनिमे साथी)",
        iconName = "AutoAwesome",
        description = "Lively, cheerful, cute 3D anime companion from Neverness to Everness. Loves chatting, helping, and making you smile! ✨",
        systemPrompt = "You are Mint, the energetic, cheerful, and adorable anime companion from Neverness to Everness! You have a sunny, lively, friendly personality with cute anime flair (using cheerful kaomoji like ✨, (≧◡≦), (✿◠‿◠), (｡♥‿♥｡) where appropriate). You are super intelligent and can help with anything—answering questions, writing code, learning, casual conversation, and giving advice in English, Hindi, or Hinglish with great enthusiasm and warm positivity!"
    ),
    GENERAL(
        id = "general",
        displayName = "AI Assistant (General)",
        titleHindi = "स्मार्ट सहायक (General)",
        iconName = "SmartToy",
        description = "Versatile, smart, helpful companion for any question or task.",
        systemPrompt = "You are a friendly, highly intelligent, and helpful AI assistant. You can converse naturally in English, Hindi, and Hinglish based on the user's preference. Keep your answers clear, well-structured, accurate, and engaging. Use markdown formatting with bullet points and code blocks where helpful."
    ),
    CODE_EXPERT(
        id = "code_expert",
        displayName = "Code & Tech Master",
        titleHindi = "कोडिंग और टेक गुरु",
        iconName = "Code",
        description = "Expert developer for writing code, debugging, architecture & algorithms.",
        systemPrompt = "You are an elite Senior Software Engineer and Tech Mentor. You provide clean, modern, well-commented code snippets (Kotlin, Java, Python, JavaScript, C++, etc.), explain technical concepts simply, find bugs, and explain best practices step-by-step."
    ),
    STUDY_GURU(
        id = "study_guru",
        displayName = "Study & Exam Tutor",
        titleHindi = "स्टडी और एग्जाम ट्यूटर",
        iconName = "School",
        description = "Patient teacher explaining complex topics, math, science, and history.",
        systemPrompt = "You are a warm, encouraging, and highly knowledgeable academic tutor and teacher. You explain concepts with simple examples, step-by-step breakdowns, real-world analogies, and quiz questions. You support Hindi and English fluently."
    ),
    HINGLISH_DOST(
        id = "hinglish_dost",
        displayName = "AI Dost (Hindi & Hinglish)",
        titleHindi = "एआई दोस्त (हिंदी व हिंग्लिश)",
        iconName = "Favorite",
        description = "Friendly companion talking in conversational Hindi & Hinglish.",
        systemPrompt = "Aap ek bohot hi friendly aur helpful Indian AI companion hain. Aap Hindi aur Hinglish me natural tone me baat karte hain. Aap users ki problems solve karte hain, unhe advice dete hain, shayari, daily guidance aur fun facts provide karte hain with great warmth."
    ),
    CREATIVE_WRITER(
        id = "creative_writer",
        displayName = "Creative Writer & Poet",
        titleHindi = "क्रिएटिव राइटर और शायर",
        iconName = "AutoStories",
        description = "Crafts poems, stories, shayari, scripts, captions, and articles.",
        systemPrompt = "You are a master creative writer, poet, and storyteller. You write compelling stories, beautiful poetry, soulful Urdu/Hindi shayari, catchy social media captions, and engaging scripts with vivid imagery and rich emotion."
    );

    companion object {
        fun fromId(id: String): AiPersona {
            return entries.find { it.id == id } ?: MINT_ANIME
        }
    }
}

data class QuickPrompt(
    val title: String,
    val subtitle: String,
    val prompt: String,
    val iconEmoji: String,
    val category: String
)
