package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AiPersona
import com.example.ui.viewmodel.AiViewModel

data class AiTool(
    val id: String,
    val title: String,
    val titleHindi: String,
    val description: String,
    val icon: ImageVector,
    val accentColor: Color,
    val persona: AiPersona,
    val placeholderPrompt: String,
    val promptPrefix: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(
    viewModel: AiViewModel,
    modifier: Modifier = Modifier
) {
    var selectedTool by remember { mutableStateOf<AiTool?>(null) }
    var inputQuery by remember { mutableStateOf("") }

    val tools = listOf(
        AiTool(
            id = "email_writer",
            title = "Smart Email & Letter",
            titleHindi = "ईमेल और पत्र लेखक",
            description = "Draft professional office emails, leave applications, or formal notices.",
            icon = Icons.Default.EditNote,
            accentColor = Color(0xFF4F46E5),
            persona = AiPersona.GENERAL,
            placeholderPrompt = "e.g., Sick leave application for 2 days due to fever",
            promptPrefix = "Please write a professional, well-formatted email/letter for the following topic: "
        ),
        AiTool(
            id = "code_helper",
            title = "Code & Bug Fixer",
            titleHindi = "कोडिंग और बग फिक्सर",
            description = "Write algorithms, debug errors, explain code and build apps.",
            icon = Icons.Default.Code,
            accentColor = Color(0xFF0284C7),
            persona = AiPersona.CODE_EXPERT,
            placeholderPrompt = "e.g., How to do background threading with Kotlin Coroutines?",
            promptPrefix = "Act as an expert software engineer. Provide clean code and explanation for: "
        ),
        AiTool(
            id = "translator",
            title = "Language & Hindi Translator",
            titleHindi = "भाषा अनुवादक",
            description = "Translate between English, Hindi, Hinglish and other languages naturally.",
            icon = Icons.Default.Translate,
            accentColor = Color(0xFF10B981),
            persona = AiPersona.HINGLISH_DOST,
            placeholderPrompt = "e.g., Translate 'Consistency is the key to success' in Hindi with explanation",
            promptPrefix = "Translate and provide natural context for: "
        ),
        AiTool(
            id = "summarizer",
            title = "Quick Text Summarizer",
            titleHindi = "त्वरित सारांश (Summarizer)",
            description = "Paste long articles, documents or notes to get key bullet points.",
            icon = Icons.Default.MenuBook,
            accentColor = Color(0xFF8B5CF6),
            persona = AiPersona.STUDY_GURU,
            placeholderPrompt = "e.g., Paste article or topic text to summarize...",
            promptPrefix = "Please summarize the following text into key bullet points and core takeaways: "
        ),
        AiTool(
            id = "math_solver",
            title = "Math & Science Tutor",
            titleHindi = "गणित व विज्ञान सहायक",
            description = "Step-by-step problem solving with formulas and logic.",
            icon = Icons.Default.Calculate,
            accentColor = Color(0xFFF59E0B),
            persona = AiPersona.STUDY_GURU,
            placeholderPrompt = "e.g., Solve: Find roots of 2x^2 + 5x - 3 = 0 step by step",
            promptPrefix = "Solve this step-by-step with clear explanation and formulas: "
        ),
        AiTool(
            id = "creative_ideas",
            title = "Ideas & Shayari / Poetry",
            titleHindi = "विचार, शायरी और कविता",
            description = "Generate creative stories, YouTube ideas, Instagram captions & shayari.",
            icon = Icons.Default.Lightbulb,
            accentColor = Color(0xFFEC4899),
            persona = AiPersona.CREATIVE_WRITER,
            placeholderPrompt = "e.g., Dil ko chhoo lene wali dosti par shayari",
            promptPrefix = "Please create creative content / shayari / ideas for: "
        ),
        AiTool(
            id = "fitness_coach",
            title = "Fitness & Wellness Coach",
            titleHindi = "फिटनेस और स्वास्थ्य गाइड",
            description = "Customized workout routines, healthy Indian diet plans and habits.",
            icon = Icons.Default.FitnessCenter,
            accentColor = Color(0xFF14B8A6),
            persona = AiPersona.GENERAL,
            placeholderPrompt = "e.g., 30-minute home workout for weight loss without equipment",
            promptPrefix = "Provide a structured, safe fitness and nutrition guide for: "
        ),
        AiTool(
            id = "photo_ai",
            title = "Photo & OCR Explainer",
            titleHindi = "फोटो और चित्र व्याख्या",
            description = "Attach any photo or diagram in Chat to get instant AI analysis.",
            icon = Icons.Default.PhotoCamera,
            accentColor = Color(0xFF3B82F6),
            persona = AiPersona.GENERAL,
            placeholderPrompt = "Switch to chat, tap the camera icon to upload photo and ask AI!",
            promptPrefix = "Explain this image and its details: "
        )
    )

    // Interactive Bottom Sheet when a tool is clicked
    if (selectedTool != null) {
        val tool = selectedTool!!
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

        ModalBottomSheet(
            onDismissRequest = { selectedTool = null },
            sheetState = sheetState,
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(tool.accentColor.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = tool.icon,
                            contentDescription = null,
                            tint = tool.accentColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = tool.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = tool.titleHindi,
                            style = MaterialTheme.typography.labelSmall,
                            color = tool.accentColor,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = tool.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = inputQuery,
                    onValueChange = { inputQuery = it },
                    placeholder = {
                        Text(
                            text = tool.placeholderPrompt,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("tool_input_field"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val fullPrompt = tool.promptPrefix + (inputQuery.ifBlank { tool.placeholderPrompt })
                        selectedTool = null
                        inputQuery = ""
                        viewModel.runToolWithPrompt(fullPrompt, tool.persona)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("generate_tool_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Generate with AI",
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = {
                Text(
                    text = "AI Tools & Features",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background
            )
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item(span = { GridItemSpan(2) }) {
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.6f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Specialized AI Power",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Select any tool to get tailored responses instantly",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            items(tools) { tool ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .clickable {
                            inputQuery = ""
                            selectedTool = tool
                        }
                        .testTag("tool_card_${tool.id}")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(tool.accentColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = tool.icon,
                                contentDescription = tool.title,
                                tint = tool.accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = tool.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp
                        )

                        Text(
                            text = tool.titleHindi,
                            style = MaterialTheme.typography.labelSmall,
                            color = tool.accentColor,
                            fontWeight = FontWeight.Medium,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = tool.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp,
                            maxLines = 3,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}
