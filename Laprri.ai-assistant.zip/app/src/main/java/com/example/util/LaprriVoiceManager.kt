package com.example.util

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import com.example.model.AppInfo
import com.example.model.LaprriLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

/**
 * LaprriVoiceManager:
 * - Hands-free continuous wake-word & dynamic Phone App Voice Launcher.
 * - Supports 3 Languages: Gujarati (ગુજરાતી), Hindi (हिन्दी), English.
 * - Opens ANY installed app on user's phone via voice.
 * - If permission is NOT granted, Laprri asks in selected language:
 *     - Gujarati: "સર, {App} ની પરમિશન મારી પાસે નથી. શું હું આ એપની પરમિશન આપી દઉં?"
 *     - Hindi: "सर, {App} की परमिशन मेरे पास नहीं है। क्या मैं इसकी परमिशन अलाउ कर दूँ?"
 *     - English: "Sir, I don't have permission for {App}. Should I grant permission for it?"
 * - Voice commands to Grant & Revoke permissions anytime.
 * - Voice and UI Language switching anytime.
 */
class LaprriVoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val packageManager: PackageManager = context.packageManager
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences("laprri_app_permissions", Context.MODE_PRIVATE)

    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false
    private var mediaPlayer: MediaPlayer? = null
    private var speechRecognizer: SpeechRecognizer? = null

    private var bluetoothHeadset: BluetoothHeadset? = null
    private var bluetoothAdapter: BluetoothAdapter? = try {
        BluetoothAdapter.getDefaultAdapter()
    } catch (_: Exception) {
        null
    }

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isBluetoothConnected = MutableStateFlow(false)
    val isBluetoothConnected: StateFlow<Boolean> = _isBluetoothConnected.asStateFlow()

    private val _bluetoothDeviceName = MutableStateFlow<String?>(null)
    val bluetoothDeviceName: StateFlow<String?> = _bluetoothDeviceName.asStateFlow()

    private val _lastDetectedWakeWord = MutableStateFlow<String?>(null)
    val lastDetectedWakeWord: StateFlow<String?> = _lastDetectedWakeWord.asStateFlow()

    // 3 Languages Support: Gujarati, Hindi, English
    private val _currentLanguage = MutableStateFlow(
        LaprriLanguage.fromCode(sharedPreferences.getString("laprri_selected_language", "hi") ?: "hi")
    )
    val currentLanguage: StateFlow<LaprriLanguage> = _currentLanguage.asStateFlow()

    private val _currentDialogue = MutableStateFlow("✨ Laprri is listening... Speak any app name to open ✨")
    val currentDialogue: StateFlow<String> = _currentDialogue.asStateFlow()

    private val _isVoiceEnabled = MutableStateFlow(true)
    val isVoiceEnabled: StateFlow<Boolean> = _isVoiceEnabled.asStateFlow()

    // Master Phone Access Switch
    private val _isPhoneAccessEnabled = MutableStateFlow(true)
    val isPhoneAccessEnabled: StateFlow<Boolean> = _isPhoneAccessEnabled.asStateFlow()

    // State for App currently waiting for user's voice permission confirmation
    private val _pendingPermissionApp = MutableStateFlow<AppInfo?>(null)
    val pendingPermissionApp: StateFlow<AppInfo?> = _pendingPermissionApp.asStateFlow()

    // List of installed applications on phone
    private val _installedApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val installedApps: StateFlow<List<AppInfo>> = _installedApps.asStateFlow()

    private val _hasCustomAudio = MutableStateFlow(false)
    val hasCustomAudio: StateFlow<Boolean> = _hasCustomAudio.asStateFlow()

    private val customAudioFiles = mutableListOf<File>()

    private var isRecognitionActive = false
    private var hasAudioPermission = false
    private var isReceiverRegistered = false

    // Wake words variants across Gujarati, Hindi, English
    private val wakeWordKeywords = listOf(
        "laprri", "lapri", "lapree", "lappri", "lepree", "lepri",
        "લપરી", "લપ્રી", "લફરી", "लपरी", "लप्री", "lafri", "labri",
        "lovery", "loverly", "laperi", "lopri", "lopree", "lupri"
    )

    private val generalWakeResponsesGujarati = listOf(
        "હા સર, બોલો! લપરી અહીં છે, કઈ એપ ખોલવી છે?",
        "જી સર! લપરી તૈયાર છે, બોલો શું ઓર્ડર છે?",
        "તમે બોલાવ્યા અને લપરી હાજર! WhatsApp, YouTube, Gallery કે કોઈ પણ એપ બોલો.",
        "હેય! હું લાઈવ સાંભળી રહી છું, બોલો કઈ એપ ચલાવવી છે?",
        "હાજી સર! લપરી તમારા આદેશ માટે તૈયાર છે!"
    )

    private val generalWakeResponsesHindi = listOf(
        "हाँ सर, बोलिए! लपरी यहाँ है, कौनसी ऐप ओपन करनी है?",
        "जी सर! लपरी तैयार है, बोलिए क्या आर्डर है?",
        "आपने बुलाया और लपरी हाजिर! WhatsApp, YouTube, Gallery या कोई भी ऐप खोलने को बोलिए।",
        "हेय! मैं लाइव सुन रही हूँ, बोलिए किसे कॉल या कौनसी ऐप चलानी है?",
        "हाँजी सर! लपरी आपके कमांड्स के लिए तैयार है!"
    )

    private val generalWakeResponsesEnglish = listOf(
        "Yes Sir! Laprri is here, which app would you like to open?",
        "Laprri is ready! Tell me your command, Sir.",
        "At your service! Say WhatsApp, YouTube, Gallery or any app to launch.",
        "Hey! I'm listening live, tell me which app you want to open.",
        "Ready and listening, Sir! What's next?"
    )

    private var lastResponseIndex = -1

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            when (action) {
                BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(BluetoothProfile.EXTRA_STATE, BluetoothProfile.STATE_DISCONNECTED)
                    if (state == BluetoothProfile.STATE_CONNECTED) {
                        checkBluetoothAudioRouting()
                    } else if (state == BluetoothProfile.STATE_DISCONNECTED) {
                        onBluetoothDisconnected()
                    }
                }
                AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED -> {
                    val state = intent.getIntExtra(AudioManager.EXTRA_SCO_AUDIO_STATE, AudioManager.SCO_AUDIO_STATE_DISCONNECTED)
                    if (state == AudioManager.SCO_AUDIO_STATE_CONNECTED) {
                        _isBluetoothConnected.value = true
                    } else if (state == AudioManager.SCO_AUDIO_STATE_DISCONNECTED) {
                        if (!isBluetoothHeadsetConnected()) {
                            _isBluetoothConnected.value = false
                            _bluetoothDeviceName.value = null
                        }
                    }
                }
                BluetoothDevice.ACTION_ACL_CONNECTED -> {
                    checkBluetoothAudioRouting()
                }
                BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                    onBluetoothDisconnected()
                }
            }
        }
    }

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile?) {
            if (profile == BluetoothProfile.HEADSET) {
                bluetoothHeadset = proxy as? BluetoothHeadset
                checkBluetoothAudioRouting()
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HEADSET) {
                bluetoothHeadset = null
                onBluetoothDisconnected()
            }
        }
    }

    init {
        tts = TextToSpeech(context.applicationContext, this)
        loadCustomAudioClips()
        loadInstalledApps()
        setupBluetoothReceiver()
        initBluetoothProfile()
    }

    fun setLanguage(language: LaprriLanguage, notifyUser: Boolean = true) {
        _currentLanguage.value = language
        sharedPreferences.edit().putString("laprri_selected_language", language.code).apply()
        setupVoiceEngine()

        if (notifyUser) {
            when (language) {
                LaprriLanguage.GUJARATI -> {
                    _currentDialogue.value = "✨ ગુજરાતી ભાષા પસંદ કરી છે ✨"
                    speakText("નમસ્તે! લપરી હવે તમારી સાથે ગુજરાતીમાં વાત કરશે.")
                }
                LaprriLanguage.HINDI -> {
                    _currentDialogue.value = "✨ हिन्दी भाषा चुनी गई है ✨"
                    speakText("नमस्ते! लपरी अब आपसे हिन्दी में बात करेगी।")
                }
                LaprriLanguage.ENGLISH -> {
                    _currentDialogue.value = "✨ English Language Selected ✨"
                    speakText("Hello! Laprri will now speak with you in English.")
                }
            }
        }
    }

    /**
     * Load all launchable apps from phone and sync with saved permission states
     */
    fun loadInstalledApps() {
        try {
            val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
                addCategory(Intent.CATEGORY_LAUNCHER)
            }
            val resolveInfos = packageManager.queryIntentActivities(mainIntent, 0)
            val allowedSet = getSavedAllowedPackages()

            val apps = resolveInfos.mapNotNull { resolveInfo ->
                val pkgName = resolveInfo.activityInfo.packageName
                if (pkgName == context.packageName) return@mapNotNull null

                val appName = resolveInfo.loadLabel(packageManager).toString()
                AppInfo(
                    appName = appName,
                    packageName = pkgName,
                    isAllowed = allowedSet.contains(pkgName)
                )
            }.sortedBy { it.appName.lowercase() }

            _installedApps.value = apps
        } catch (_: Exception) {}
    }

    private fun getSavedAllowedPackages(): Set<String> {
        return sharedPreferences.getStringSet("allowed_packages", emptySet()) ?: emptySet()
    }

    private fun saveAllowedPackages(packages: Set<String>) {
        sharedPreferences.edit().putStringSet("allowed_packages", packages).apply()
        loadInstalledApps()
    }

    fun isAppAllowed(packageName: String): Boolean {
        return getSavedAllowedPackages().contains(packageName)
    }

    fun grantPermissionForApp(app: AppInfo) {
        val currentSet = getSavedAllowedPackages().toMutableSet()
        currentSet.add(app.packageName)
        saveAllowedPackages(currentSet)
    }

    fun revokePermissionForApp(app: AppInfo) {
        val currentSet = getSavedAllowedPackages().toMutableSet()
        currentSet.remove(app.packageName)
        saveAllowedPackages(currentSet)
    }

    fun grantAllPermissions() {
        val allPkgs = _installedApps.value.map { it.packageName }.toSet()
        saveAllowedPackages(allPkgs)
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("સર, બધી એપ્સને પરમિશન આપી દીધી છે.")
            LaprriLanguage.HINDI -> speakText("सर, सभी ऐप्स को परमिशन अलाउ कर दी गई है।")
            LaprriLanguage.ENGLISH -> speakText("Sir, permissions for all applications have been granted.")
        }
    }

    fun revokeAllPermissions() {
        saveAllowedPackages(emptySet())
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("સર, બધી એપ્સની પરમિશન હટાવી દીધી છે.")
            LaprriLanguage.HINDI -> speakText("सर, सभी ऐप्स की परमिशन हटा दी गई है।")
            LaprriLanguage.ENGLISH -> speakText("Sir, permissions for all applications have been revoked.")
        }
    }

    fun toggleAppPermission(app: AppInfo) {
        if (app.isAllowed) {
            revokePermissionForApp(app)
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("${app.appName} ની પરમિશન હટાવી દીધી છે.")
                LaprriLanguage.HINDI -> speakText("${app.appName} की परमिशन हटा दी गई है।")
                LaprriLanguage.ENGLISH -> speakText("Permission removed for ${app.appName}.")
            }
        } else {
            grantPermissionForApp(app)
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("${app.appName} ને પરમિશન આપી દીધી છે.")
                LaprriLanguage.HINDI -> speakText("${app.appName} को परमिशन दे दी गई है।")
                LaprriLanguage.ENGLISH -> speakText("Permission granted for ${app.appName}.")
            }
        }
    }

    fun setPhoneAccessEnabled(enabled: Boolean) {
        _isPhoneAccessEnabled.value = enabled
        if (enabled) {
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ફોન એક્સેસ ચાલુ કરી દીધું છે. હવે તમે બોલીને કોઈપણ એપ ખોલી શકો છો.")
                LaprriLanguage.HINDI -> speakText("फ़ोन एक्सेस चालू कर दिया गया है। अब आप वॉइस से कोई भी ऐप ओपन कर सकते हैं।")
                LaprriLanguage.ENGLISH -> speakText("Phone voice access is now enabled. You can launch any app by voice.")
            }
        } else {
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ફોન એક્સેસ બંધ કરી દીધું છે.")
                LaprriLanguage.HINDI -> speakText("फ़ोन एक्सेस बंद कर दिया गया है।")
                LaprriLanguage.ENGLISH -> speakText("Phone voice access has been disabled.")
            }
        }
    }

    private fun setupBluetoothReceiver() {
        try {
            val filter = IntentFilter().apply {
                addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
                addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED)
                addAction(BluetoothDevice.ACTION_ACL_CONNECTED)
                addAction(BluetoothDevice.ACTION_ACL_DISCONNECTED)
                addAction(Intent.ACTION_HEADSET_PLUG)
            }
            context.registerReceiver(bluetoothReceiver, filter)
            isReceiverRegistered = true
        } catch (_: Exception) {}
    }

    private fun initBluetoothProfile() {
        try {
            bluetoothAdapter?.getProfileProxy(context, profileListener, BluetoothProfile.HEADSET)
        } catch (_: Exception) {}
    }

    fun checkBluetoothAudioRouting() {
        mainHandler.post {
            try {
                var isBt = false
                var devName: String? = null

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val commDevices = audioManager.availableCommunicationDevices
                    val btCommDevice = commDevices.firstOrNull { dev ->
                        dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        dev.type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                        dev.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
                    }

                    if (btCommDevice != null) {
                        audioManager.setCommunicationDevice(btCommDevice)
                        isBt = true
                        devName = btCommDevice.productName?.toString() ?: "Bluetooth Headset"
                    }
                }

                if (!isBt && isBluetoothHeadsetConnected()) {
                    isBt = true
                    try {
                        if (audioManager.isBluetoothScoAvailableOffCall) {
                            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
                            audioManager.startBluetoothSco()
                            audioManager.isBluetoothScoOn = true
                        }
                    } catch (_: Exception) {}
                }

                _isBluetoothConnected.value = isBt
                _bluetoothDeviceName.value = devName ?: if (isBt) "Bluetooth Device" else null
            } catch (_: Exception) {}
        }
    }

    private fun isBluetoothHeadsetConnected(): Boolean {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT)
                    != PackageManager.PERMISSION_GRANTED) {
                    return audioManager.isBluetoothScoOn || audioManager.isBluetoothA2dpOn
                }
            }
            val devices = bluetoothHeadset?.connectedDevices
            if (!devices.isNullOrEmpty()) {
                _bluetoothDeviceName.value = devices.firstOrNull()?.name ?: "Bluetooth Device"
                return true
            }
            return audioManager.isBluetoothScoOn || audioManager.isBluetoothA2dpOn
        } catch (_: Exception) {
            return false
        }
    }

    private fun onBluetoothDisconnected() {
        mainHandler.post {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    audioManager.clearCommunicationDevice()
                }
                audioManager.isBluetoothScoOn = false
                audioManager.stopBluetoothSco()
                audioManager.mode = AudioManager.MODE_NORMAL
            } catch (_: Exception) {}
            _isBluetoothConnected.value = false
            _bluetoothDeviceName.value = null
        }
    }

    private fun loadCustomAudioClips() {
        try {
            val audioDir = File(context.filesDir, "custom_voices")
            if (audioDir.exists()) {
                val files = audioDir.listFiles { file ->
                    file.extension.lowercase() in listOf("mp3", "wav", "m4a", "ogg", "aac")
                }
                if (!files.isNullOrEmpty()) {
                    customAudioFiles.clear()
                    customAudioFiles.addAll(files)
                    _hasCustomAudio.value = true
                }
            }
        } catch (_: Exception) {}
    }

    fun setPermissionGranted(granted: Boolean) {
        hasAudioPermission = granted
        if (granted) {
            checkBluetoothAudioRouting()
            startContinuousListening()
        }
    }

    fun startContinuousListening() {
        if (!hasAudioPermission) return
        mainHandler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(context)) return@post

                checkBluetoothAudioRouting()

                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                        setRecognitionListener(createRecognitionListener())
                    }
                }

                if (!_isSpeaking.value) {
                    val langTag = _currentLanguage.value.localeTag
                    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
                        putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                        putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
                        putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    }
                    speechRecognizer?.startListening(intent)
                    _isListening.value = true
                    isRecognitionActive = true
                }
            } catch (_: Exception) {
                _isListening.value = false
                isRecognitionActive = false
                restartListeningWithDelay(2000)
            }
        }
    }

    private fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (_: Exception) {}
            _isListening.value = false
            isRecognitionActive = false
        }
    }

    private fun restartListeningWithDelay(delayMs: Long = 600) {
        mainHandler.removeCallbacksAndMessages(null)
        mainHandler.postDelayed({
            if (hasAudioPermission && !_isSpeaking.value) {
                startContinuousListening()
            }
        }, delayMs)
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _isListening.value = true
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _isListening.value = false
            }

            override fun onError(error: Int) {
                _isListening.value = false
                isRecognitionActive = false
                restartListeningWithDelay(800)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                checkMatchesForWakeWordAndCommands(matches)
                restartListeningWithDelay(500)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                checkMatchesForWakeWordAndCommands(partialResults = matches, isPartial = true)
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun checkMatchesForWakeWordAndCommands(matches: ArrayList<String>? = null, partialResults: ArrayList<String>? = null, isPartial: Boolean = false) {
        val list = matches ?: partialResults ?: return
        if (list.isEmpty() || _isSpeaking.value) return

        for (phrase in list) {
            val lower = phrase.lowercase().trim()
            val containsWakeWord = wakeWordKeywords.any { kw -> lower.contains(kw) }

            // Check if user is asking for language switch or answering a pending permission question, or direct voice action commands
            if (_pendingPermissionApp.value != null ||
                containsWakeWord ||
                lower.contains("gujarati") || lower.contains("ગુજરાતી") ||
                lower.contains("hindi") || lower.contains("हिन्दी") || lower.contains("हिंदी") ||
                lower.contains("english") || lower.contains("ઇંગ્લિશ") ||
                lower.startsWith("open") || lower.startsWith("kholo") || lower.startsWith("chalao") || lower.startsWith("chalu") ||
                lower.startsWith("ખોલો") || lower.startsWith("ચાલુ") ||
                lower.startsWith("call") || lower.startsWith("message") || lower.startsWith("band") ||
                lower.startsWith("close") || lower.contains("permission") || lower.contains("પરમિશન") || lower.contains("access")) {
                
                _lastDetectedWakeWord.value = "Heard: \"$lower\""
                processVoiceCommand(lower)
                break
            }
        }
    }

    /**
     * Main Multilingual Voice Command Processor:
     * - Language switching ("Laprri Gujarati ma bolo", "Laprri Hindi me bolo", "Laprri Speak English")
     * - Pending Permission confirmation (Yes/No in Gujarati, Hindi, English)
     * - Revoke permission for any app
     * - Grant permission for any app
     * - Open any installed app
     * - Calling, SMS, Location, Mail, Close, Master Access
     */
    private fun processVoiceCommand(spokenText: String) {
        val text = spokenText.lowercase().trim()

        // 1. Language Switching Voice Commands
        if (text.contains("gujarati") || text.contains("ગુજરાતી") || text.contains("gujrati")) {
            if (text.contains("bolo") || text.contains("bhasha") || text.contains("bhasa") || text.contains("language") ||
                text.contains("switch") || text.contains("change") || text.contains("karo") || text.contains("vaat karo")) {
                stopListening()
                setLanguage(LaprriLanguage.GUJARATI, notifyUser = true)
                return
            }
        }

        if (text.contains("hindi") || text.contains("हिन्दी") || text.contains("हिंदी")) {
            if (text.contains("bolo") || text.contains("bhasha") || text.contains("bhasa") || text.contains("language") ||
                text.contains("switch") || text.contains("change") || text.contains("karo") || text.contains("baat karo")) {
                stopListening()
                setLanguage(LaprriLanguage.HINDI, notifyUser = true)
                return
            }
        }

        if (text.contains("english") || text.contains("अंग्रेजी") || text.contains("ઇંગ્લિશ") || text.contains("inglish")) {
            if (text.contains("speak") || text.contains("bolo") || text.contains("talk") || text.contains("language") ||
                text.contains("switch") || text.contains("change") || text.contains("karo")) {
                stopListening()
                setLanguage(LaprriLanguage.ENGLISH, notifyUser = true)
                return
            }
        }

        // 2. Check if we are waiting for user's permission response for a pending app
        val pendingApp = _pendingPermissionApp.value
        if (pendingApp != null) {
            if (isAffirmative(text)) {
                stopListening()
                grantPermissionForApp(pendingApp)
                _pendingPermissionApp.value = null
                val openMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "જી સર, ${pendingApp.appName} ને પરમિશન આપી દીધી છે. હવે ઓપન કરી રહી છું..."
                    LaprriLanguage.HINDI -> "जी सर, ${pendingApp.appName} को परमिशन दे दी गई है। अब ओपन कर रही हूँ..."
                    LaprriLanguage.ENGLISH -> "Yes Sir, permission granted for ${pendingApp.appName}. Opening now..."
                }
                _currentDialogue.value = "✅ Permission granted for ${pendingApp.appName}. Opening now..."
                speakText(openMsg)
                mainHandler.postDelayed({
                    launchAppByPackage(pendingApp.packageName, pendingApp.appName)
                }, 1000)
                return
            } else if (isNegative(text)) {
                stopListening()
                _pendingPermissionApp.value = null
                val deniedMsg = when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> "ઠીક છે સર, ${pendingApp.appName} ની પરમિશન નથી આપી."
                    LaprriLanguage.HINDI -> "ठीक है सर, ${pendingApp.appName} की परमिशन नहीं दी गई।"
                    LaprriLanguage.ENGLISH -> "Alright Sir, permission was denied for ${pendingApp.appName}."
                }
                _currentDialogue.value = "❌ Permission denied for ${pendingApp.appName}."
                speakText(deniedMsg)
                return
            }
        }

        // 3. Phone Access Master Toggle Commands
        if (text.contains("access off") || text.contains("access band") || text.contains("permission band") ||
            text.contains("phone band karo") || text.contains("એક્સેસ બંધ") || text.contains("ફોન બંધ કરો")) {
            stopListening()
            _isPhoneAccessEnabled.value = false
            _currentDialogue.value = "🔒 Phone access disabled by voice command."
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ઠીક છે, ફોન એક્સેસ બંધ કરી દીધું છે.")
                LaprriLanguage.HINDI -> speakText("ठीक है, फ़ोन एक्सेस बंद कर दिया है।")
                LaprriLanguage.ENGLISH -> speakText("Phone voice access has been disabled.")
            }
            return
        }

        if (text.contains("access on") || text.contains("access chalu") || text.contains("permission chalu") ||
            text.contains("phone chalu karo") || text.contains("એક્સેસ ચાલુ") || text.contains("ફોન ચાલુ કરો")) {
            stopListening()
            _isPhoneAccessEnabled.value = true
            _currentDialogue.value = "🔓 Phone access enabled by voice command."
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ફોન એક્સેસ ચાલુ કરી દીધું છે. તમે કોઈપણ એપનું નામ બોલીને તેને ખોલી શકો છો.")
                LaprriLanguage.HINDI -> speakText("फ़ोन एक्सेस चालू कर दिया है। आप किसी भी ऐप का नाम बोलकर उसे ओपन कर सकते हैं।")
                LaprriLanguage.ENGLISH -> speakText("Phone voice access enabled. You can speak any app name to open it.")
            }
            return
        }

        // 4. Remove / Revoke Permission Voice Commands (e.g. "WhatsApp ki permission hata do", "WhatsApp ni permission hatavo")
        if (text.contains("permission hata") || text.contains("permission band") || text.contains("permission remove") ||
            text.contains("remove permission") || text.contains("revoke permission") || text.contains("permission cancel") ||
            text.contains("access hata") || text.contains("access band") || text.contains("પરમિશન હટાવો") || text.contains("પરમિશન બંધ")) {
            
            stopListening()
            if (text.contains("sab") || text.contains("all") || text.contains("badhi") || text.contains("બધી")) {
                revokeAllPermissions()
                _currentDialogue.value = "🔒 All app permissions removed."
                return
            }

            val targetApp = findAppInQuery(text)
            if (targetApp != null) {
                revokePermissionForApp(targetApp)
                _currentDialogue.value = "🚫 Permission removed for ${targetApp.appName}."
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, ${targetApp.appName} ની પરમિશન સફળતાપૂર્વક હટાવી દીધી છે.")
                    LaprriLanguage.HINDI -> speakText("सर, ${targetApp.appName} की परमिशन सफलतापूर्वक हटा दी गई है।")
                    LaprriLanguage.ENGLISH -> speakText("Sir, permission for ${targetApp.appName} has been revoked successfully.")
                }
            } else {
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, તમે કઈ એપની પરમિશન હટાવવા માંગો છો?")
                    LaprriLanguage.HINDI -> speakText("सर, आप कौनसी ऐप की परमिशन हटाना चाहते हैं?")
                    LaprriLanguage.ENGLISH -> speakText("Sir, which app's permission would you like to remove?")
                }
            }
            return
        }

        // 5. Grant Permission explicitly by voice (e.g. "WhatsApp ko permission de do", "WhatsApp ne permission aapo")
        if (text.contains("permission de do") || text.contains("permission allow") || text.contains("allow permission") ||
            text.contains("permission chalu") || text.contains("permission dedo") || text.contains("પરમિશન આપો") ||
            text.contains("પરમિશન આપી દો") || text.contains("પરમિશન ચાલુ")) {
            
            stopListening()
            if (text.contains("sab") || text.contains("all") || text.contains("badhi") || text.contains("બધી")) {
                grantAllPermissions()
                _currentDialogue.value = "🔓 All app permissions granted."
                return
            }

            val targetApp = findAppInQuery(text)
            if (targetApp != null) {
                grantPermissionForApp(targetApp)
                _currentDialogue.value = "✅ Permission granted for ${targetApp.appName}."
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, ${targetApp.appName} ને પરમિશન આપી દીધી છે.")
                    LaprriLanguage.HINDI -> speakText("सर, ${targetApp.appName} को परमिशन अलाउ कर दी गई है।")
                    LaprriLanguage.ENGLISH -> speakText("Sir, permission granted for ${targetApp.appName}.")
                }
            } else {
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, તમે કઈ એપને પરમિશન આપવા માંગો છો?")
                    LaprriLanguage.HINDI -> speakText("सर, आप कौनसी ऐप को परमिशन देना चाहते हैं?")
                    LaprriLanguage.ENGLISH -> speakText("Sir, which app would you like to grant permission for?")
                }
            }
            return
        }

        // 6. Close / Back / Go Home Command
        if (text.contains("close") || text.contains("band karo") || text.contains("home") ||
            text.contains("piche jao") || text.contains("exit") || text.contains("પાછા જાઓ") ||
            text.contains("બંધ કરો") || text.contains("હોમ સ્ક્રીન")) {
            stopListening()
            _currentDialogue.value = "🏠 Closing to Home Screen..."
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ઠીક છે સર, પાછા હોમ સ્ક્રીન પર જઈ રહી છું...")
                LaprriLanguage.HINDI -> speakText("ठीक है सर, बैक जा रही हूँ...")
                LaprriLanguage.ENGLISH -> speakText("Going back to Home screen, Sir...")
            }
            mainHandler.postDelayed({
                try {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(homeIntent)
                } catch (_: Exception) {}
            }, 800)
            return
        }

        // 7. Direct Built-in Commands: Calling / SMS / Location / Mail
        if (text.contains("dial") || (text.contains("call") && !text.contains("calling app")) ||
            text.contains("ફોન કરો") || text.contains("કોલ કરો") || text.contains("call lagao")) {
            handleCallCommand(text)
            return
        }

        if (text.contains("message") || text.contains("sms") || text.contains("text bhejo") ||
            text.contains("msg") || text.contains("મેસેજ") || text.contains("મેસેજ મોકલો")) {
            handleSmsCommand()
            return
        }

        if (text.contains("location") || text.contains("map") || text.contains("kahan hu") ||
            text.contains("navigation") || text.contains("rasta") || text.contains("લોકેશન") ||
            text.contains("નકશો") || text.contains("હું ક્યાં છું")) {
            handleLocationCommand()
            return
        }

        if (text.contains("email") || (text.contains("mail") && !text.contains("gmail")) || text.contains("મેઇલ")) {
            handleMailCommand()
            return
        }

        // 8. General App Launcher by Voice (Matches ANY app on user's phone in Gujarati, Hindi, English!)
        val detectedApp = findAppInQuery(text)
        if (detectedApp != null) {
            stopListening()
            if (!_isPhoneAccessEnabled.value) {
                _currentDialogue.value = "⚠️ Phone access is turned off."
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("ફોન એક્સેસ અત્યારે બંધ છે. કૃપા કરીને પહેલા એક્સેસ ચાલુ કરો.")
                    LaprriLanguage.HINDI -> speakText("फ़ोन एक्सेस अभी बंद है। कृपया पहले एक्सेस ऑन करें।")
                    LaprriLanguage.ENGLISH -> speakText("Phone access is currently off. Please turn on access first.")
                }
                return
            }

            // Check if this specific app is permitted
            if (isAppAllowed(detectedApp.packageName)) {
                _currentDialogue.value = "🚀 Opening ${detectedApp.appName}..."
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("જી સર, ${detectedApp.appName} ખોલી રહી છું...")
                    LaprriLanguage.HINDI -> speakText("जी सर, ${detectedApp.appName} ओपन कर रही हूँ...")
                    LaprriLanguage.ENGLISH -> speakText("Opening ${detectedApp.appName} now, Sir...")
                }
                mainHandler.postDelayed({
                    launchAppByPackage(detectedApp.packageName, detectedApp.appName)
                }, 800)
            } else {
                // Not permitted yet -> Ask user for permission in chosen language!
                _pendingPermissionApp.value = detectedApp
                _currentDialogue.value = "⚠️ Permission needed for ${detectedApp.appName}"
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, ${detectedApp.appName} ની પરમિશન મારી પાસે નથી. શું હું આ એપની પરમિશન આપી દઉં?")
                    LaprriLanguage.HINDI -> speakText("सर, ${detectedApp.appName} की परमिशन मेरे पास नहीं है। क्या मैं इसकी परमिशन अलाउ कर दूँ?")
                    LaprriLanguage.ENGLISH -> speakText("Sir, I don't have permission for ${detectedApp.appName}. Should I grant permission for it?")
                }
            }
            return
        }

        // 9. Default: General Wake Response in current language
        triggerWakeResponse(spokenText)
    }

    private fun isAffirmative(text: String): Boolean {
        return text.contains("haan") || text.contains("ha") || text.contains("yes") ||
               text.contains("de do") || text.contains("allow") || text.contains("chalu") ||
               text.contains("theek hai") || text.contains("ok") || text.contains("kar do") ||
               text.contains("bhejo") || text.contains("open") || text.contains("sure") ||
               text.contains("હા") || text.contains("આપો") || text.contains("આપી દો") ||
               text.contains("ચાલુ કરો") || text.contains("કરી દો") || text.contains("ઠીક છે")
    }

    private fun isNegative(text: String): Boolean {
        return text.contains("nahi") || text.contains("no") || text.contains("cancel") ||
               text.contains("mat do") || text.contains("rehne do") || text.contains("don't") ||
               text.contains("band") || text.contains("stop") ||
               text.contains("ના") || text.contains("નથી") || text.contains("રહેવા દો") ||
               text.contains("ના આપો") || text.contains("બંધ")
    }

    /**
     * Finds any matching app on the phone from spoken text query in Gujarati, Hindi or English
     */
    private fun findAppInQuery(spokenText: String): AppInfo? {
        val apps = _installedApps.value
        if (apps.isEmpty()) return null

        // Clean query by removing common prefix & suffix words across languages
        var query = spokenText.lowercase()
        for (kw in wakeWordKeywords) query = query.replace(kw, "")
        query = query.replace("open", "")
                     .replace("kholo", "")
                     .replace("chalao", "")
                     .replace("chalu karo", "")
                     .replace("chalu", "")
                     .replace("start", "")
                     .replace("launch", "")
                     .replace("dikhao", "")
                     .replace("ખોલો", "")
                     .replace("ચાલુ કરો", "")
                     .replace("ચાલુ", "")
                     .replace("બતાવો", "")
                     .replace("permission", "")
                     .replace("પરમિશન", "")
                     .replace("access", "")
                     .replace("એક્સેસ", "")
                     .replace("hata do", "")
                     .replace("band karo", "")
                     .replace("હટાવો", "")
                     .replace("બંધ કરો", "")
                     .replace("remove", "")
                     .replace("revoke", "")
                     .replace("de do", "")
                     .replace("aapo", "")
                     .replace("aapi do", "")
                     .replace("આપો", "")
                     .replace("આપી દો", "")
                     .replace("allow", "")
                     .replace("ki", "")
                     .replace("ko", "")
                     .replace("ka", "")
                     .replace("ni", "")
                     .replace("ne", "")
                     .replace("nu", "")
                     .replace("ની", "")
                     .replace("ને", "")
                     .replace("નું", "")
                     .replace("app", "")
                     .replace("application", "")
                     .replace("એપ", "")
                     .trim()

        if (query.isBlank()) return null

        // 1. Alias Matching
        val aliasMatch = matchAlias(query, apps)
        if (aliasMatch != null) return aliasMatch

        // 2. Exact match against App Name
        val exact = apps.firstOrNull { it.appName.lowercase() == query }
        if (exact != null) return exact

        // 3. Substring / Prefix match
        val partial = apps.firstOrNull { 
            val name = it.appName.lowercase()
            name.contains(query) || query.contains(name)
        }
        if (partial != null) return partial

        // 4. Package Name Substring match (e.g. com.whatsapp -> whatsapp)
        val pkgMatch = apps.firstOrNull {
            it.packageName.lowercase().contains(query)
        }
        return pkgMatch
    }

    private fun matchAlias(query: String, apps: List<AppInfo>): AppInfo? {
        val aliasMap = mapOf(
            "whatsapp" to listOf("whatsapp", "whats app", "watsapp", "વોટ્સએપ", "વૉટ્સએપ", "व्हाट्सएप"),
            "youtube" to listOf("youtube", "you tube", "yt", "યૂટ્યૂબ", "યુટ્યુબ", "यूट्यूब"),
            "instagram" to listOf("instagram", "insta", "ig", "ઇન્સ્ટાગ્રામ", "ઇન્સ્ટા", "इंस्टाग्राम"),
            "chrome" to listOf("chrome", "browser", "internet", "ક્રોમ", "બ્રાઉઝર", "क्रोम"),
            "camera" to listOf("camera", "cam", "kamera", "કેમેરા", "કેમેરો", "कैमरा"),
            "gallery" to listOf("gallery", "photos", "photo", "tasveer", "album", "ગેલેરી", "ફોટા", "गैलरी"),
            "gmail" to listOf("gmail", "google mail", "જીમેઇલ", "જીમેલ", "जीमेल"),
            "maps" to listOf("maps", "google maps", "map", "મેપ્સ", "નકશો", "मैप्स"),
            "settings" to listOf("settings", "setting", "phone settings", "સેટિંગ્સ", "સેટિંગ", "सेटिंग्स"),
            "calculator" to listOf("calculator", "calc", "hisaab", "કેલ્ક્યુલેટર", "ગણતરી", "कैलकुलेटर"),
            "contacts" to listOf("contacts", "contact", "phonebook", "કોન્ટેક્ટ્સ", "કોન્ટેક્ટ", "कॉन्टेक्ट्स"),
            "spotify" to listOf("spotify", "music", "gaana", "સંગીત", "ગાના", "स्पॉटिफाई"),
            "facebook" to listOf("facebook", "fb", "ફેસબુક", "फेसबुक"),
            "telegram" to listOf("telegram", "tg", "ટેલિગ્રામ", "टेलीग्राम"),
            "paytm" to listOf("paytm", "પેટીએમ", "પેટીએમ"),
            "gpay" to listOf("gpay", "google pay", "googlepay", "જીપે"),
            "phonepe" to listOf("phonepe", "phone pe", "ફોનપે", "फ़ोनपे"),
            "clock" to listOf("clock", "alarm", "ghadi", "ઘડિયાળ", "અલાર્મ", "घड़ी"),
            "files" to listOf("files", "file manager", "my files", "ફાઇલ્સ", "फ़ाइल्स"),
            "calendar" to listOf("calendar", "pancahang", "કેલેન્ડર", "પંચાંગ", "कैलेंडर")
        )

        for ((targetKey, aliases) in aliasMap) {
            if (aliases.any { query.contains(it) || it == query }) {
                val found = apps.firstOrNull { app ->
                    val name = app.appName.lowercase()
                    val pkg = app.packageName.lowercase()
                    name.contains(targetKey) || pkg.contains(targetKey)
                }
                if (found != null) return found
            }
        }
        return null
    }

    private fun launchAppByPackage(packageName: String, appName: String) {
        try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)?.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            if (launchIntent != null) {
                context.startActivity(launchIntent)
            } else {
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("સર, $appName ઓપન નથી થઈ શકી.")
                    LaprriLanguage.HINDI -> speakText("सर, $appName ओपन नहीं हो पाई।")
                    LaprriLanguage.ENGLISH -> speakText("Sir, unable to open $appName.")
                }
            }
        } catch (_: Exception) {
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("સર, $appName ઓપન કરવામાં સમસ્યા આવી.")
                LaprriLanguage.HINDI -> speakText("सर, $appName ओपन करने में दिक्कत आई।")
                LaprriLanguage.ENGLISH -> speakText("Sir, there was an issue launching $appName.")
            }
        }
    }

    private fun handleCallCommand(text: String) {
        stopListening()
        val digits = text.filter { it.isDigit() }
        val intent = if (digits.length >= 3) {
            Intent(Intent.ACTION_DIAL, Uri.parse("tel:$digits")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        } else {
            Intent(Intent.ACTION_DIAL).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
        }

        _currentDialogue.value = "📞 Opening Dialer / Calling..."
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("કોલિંગ ઓપન કરી રહી છું...")
            LaprriLanguage.HINDI -> speakText("कॉलिंग ओपन कर रही हूँ...")
            LaprriLanguage.ENGLISH -> speakText("Opening phone dialer...")
        }
        mainHandler.postDelayed({
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                speakText("Dialer not available.")
            }
        }, 800)
    }

    private fun handleSmsCommand() {
        stopListening()
        val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("smsto:")
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        _currentDialogue.value = "💬 Opening Messages..."
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("મેસેજિંગ ઓપન કરી રહી છું...")
            LaprriLanguage.HINDI -> speakText("मैसेजिंग ओपन कर रही हूँ...")
            LaprriLanguage.ENGLISH -> speakText("Opening messaging...")
        }
        mainHandler.postDelayed({
            try {
                context.startActivity(smsIntent)
            } catch (_: Exception) {
                speakText("Messages not available.")
            }
        }, 800)
    }

    private fun handleLocationCommand() {
        stopListening()
        val mapIntent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=my+location")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        _currentDialogue.value = "📍 Opening Location & Maps..."
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("લોકેશન અને મેપ્સ ઓપન કરી રહી છું...")
            LaprriLanguage.HINDI -> speakText("लोकेशन और मैप्स ओपन कर रही हूँ...")
            LaprriLanguage.ENGLISH -> speakText("Opening location and maps...")
        }
        mainHandler.postDelayed({
            try {
                context.startActivity(mapIntent)
            } catch (_: Exception) {
                speakText("Maps not available.")
            }
        }, 800)
    }

    private fun handleMailCommand() {
        stopListening()
        val mailIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        _currentDialogue.value = "✉️ Opening Mail / Email..."
        when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> speakText("મેઇલ ઓપન કરી રહી છું...")
            LaprriLanguage.HINDI -> speakText("मेल ओपन कर रही हूँ...")
            LaprriLanguage.ENGLISH -> speakText("Opening email...")
        }
        mainHandler.postDelayed({
            try {
                context.startActivity(mailIntent)
            } catch (_: Exception) {
                speakText("Email app not available.")
            }
        }, 800)
    }

    fun confirmPendingPermission(allow: Boolean) {
        val pendingApp = _pendingPermissionApp.value ?: return
        if (allow) {
            grantPermissionForApp(pendingApp)
            _pendingPermissionApp.value = null
            _currentDialogue.value = "✅ Permission granted for ${pendingApp.appName}. Opening now..."
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("જી સર, ${pendingApp.appName} ને પરમિશન આપી દીધી છે. હવે ઓપન કરી રહી છું...")
                LaprriLanguage.HINDI -> speakText("जी सर, ${pendingApp.appName} को परमिशन दे दी गई है। अब ओपन कर रही हूँ...")
                LaprriLanguage.ENGLISH -> speakText("Permission granted for ${pendingApp.appName}. Opening now...")
            }
            mainHandler.postDelayed({
                launchAppByPackage(pendingApp.packageName, pendingApp.appName)
            }, 800)
        } else {
            _pendingPermissionApp.value = null
            _currentDialogue.value = "❌ Permission denied for ${pendingApp.appName}."
            when (_currentLanguage.value) {
                LaprriLanguage.GUJARATI -> speakText("ઠીક છે સર, પરમિશન નથી આપી.")
                LaprriLanguage.HINDI -> speakText("ठीक है सर, परमिशन नहीं दी गई।")
                LaprriLanguage.ENGLISH -> speakText("Alright Sir, permission denied.")
            }
        }
    }

    fun triggerWakeResponse(spokenPhrase: String = "Laprri") {
        if (!_isVoiceEnabled.value) return

        stopListening()

        if (customAudioFiles.isNotEmpty()) {
            val file = customAudioFiles.random()
            playAudioFile(file, "✨ Laprri heard you! Playing voice response...")
            return
        }

        val responses = when (_currentLanguage.value) {
            LaprriLanguage.GUJARATI -> generalWakeResponsesGujarati
            LaprriLanguage.HINDI -> generalWakeResponsesHindi
            LaprriLanguage.ENGLISH -> generalWakeResponsesEnglish
        }

        var nextIdx: Int
        do {
            nextIdx = (0 until responses.size).random()
        } while (nextIdx == lastResponseIndex && responses.size > 1)
        lastResponseIndex = nextIdx

        val response = responses[nextIdx]
        _currentDialogue.value = response
        speakText(response)
    }

    fun addCustomAudioClip(uri: Uri, title: String = "Custom Voice") {
        try {
            val audioDir = File(context.filesDir, "custom_voices")
            if (!audioDir.exists()) audioDir.mkdirs()
            val destFile = File(audioDir, "voice_${System.currentTimeMillis()}.${context.contentResolver.getType(uri)?.substringAfterLast("/") ?: "mp3"}")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(destFile).use { output ->
                    input.copyTo(output)
                }
            }
            customAudioFiles.add(destFile)
            _hasCustomAudio.value = true
            _currentDialogue.value = "Custom Voice Note added: $title"
            playAudioFile(destFile, title)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun playAudioFile(file: File, label: String = "Playing custom audio") {
        if (!_isVoiceEnabled.value) return
        stop()
        try {
            checkBluetoothAudioRouting()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(if (_isBluetoothConnected.value) AudioAttributes.USAGE_VOICE_COMMUNICATION else AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(file.absolutePath)
                setOnPreparedListener {
                    _isSpeaking.value = true
                    _currentDialogue.value = label
                    start()
                }
                setOnCompletionListener {
                    _isSpeaking.value = false
                    releaseMediaPlayer()
                    restartListeningWithDelay(600)
                }
                setOnErrorListener { _, _, _ ->
                    _isSpeaking.value = false
                    releaseMediaPlayer()
                    restartListeningWithDelay(600)
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            _isSpeaking.value = false
            restartListeningWithDelay(600)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsInitialized = true
            setupVoiceEngine()

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                    restartListeningWithDelay(600)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                    restartListeningWithDelay(600)
                }
            })

            if (_isVoiceEnabled.value) {
                when (_currentLanguage.value) {
                    LaprriLanguage.GUJARATI -> speakText("નમસ્તે સર! હું લપરી છું. તમે કોઈપણ એપનું નામ બોલીને તેને ખોલી શકો છો.")
                    LaprriLanguage.HINDI -> speakText("नमस्ते सर! मैं लपरी हूँ। आप किसी भी ऐप का नाम बोलकर उसे ओपन कर सकते हैं।")
                    LaprriLanguage.ENGLISH -> speakText("Hello Sir! I am Laprri. You can speak any app name to open it instantly.")
                }
            }
        }
    }

    private fun setupVoiceEngine() {
        val ttsInstance = tts ?: return
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                .build()
            ttsInstance.setAudioAttributes(audioAttributes)

            val currentLang = _currentLanguage.value
            val targetLocale = when (currentLang) {
                LaprriLanguage.GUJARATI -> Locale("gu", "IN")
                LaprriLanguage.HINDI -> Locale("hi", "IN")
                LaprriLanguage.ENGLISH -> Locale("en", "IN")
            }

            val result = ttsInstance.setLanguage(targetLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // If specific regional voice pack is missing, fallback to available Indian/English locale
                ttsInstance.language = Locale("hi", "IN")
            }

            val availableVoices = ttsInstance.voices
            val femaleVoice = availableVoices?.firstOrNull { voice ->
                val name = voice.name.lowercase()
                !voice.isNetworkConnectionRequired && (
                    (currentLang == LaprriLanguage.GUJARATI && (name.contains("gu-in") || name.contains("gujarati"))) ||
                    (currentLang == LaprriLanguage.HINDI && (name.contains("hi-in") || name.contains("female") || name.contains("hi-in-x-cfn"))) ||
                    (currentLang == LaprriLanguage.ENGLISH && (name.contains("en-in") || name.contains("en-us") || name.contains("female")))
                )
            } ?: availableVoices?.firstOrNull { voice ->
                voice.name.lowercase().contains("female")
            }

            if (femaleVoice != null) {
                ttsInstance.voice = femaleVoice
            }

            ttsInstance.setPitch(1.20f)
            ttsInstance.setSpeechRate(0.95f)
        } catch (_: Exception) {
            ttsInstance.language = Locale("hi", "IN")
            ttsInstance.setPitch(1.20f)
            ttsInstance.setSpeechRate(0.95f)
        }
    }

    fun toggleVoice() {
        val next = !_isVoiceEnabled.value
        _isVoiceEnabled.value = next
        if (!next) {
            stop()
        } else {
            speakText("Voice enabled! Laprri is listening...")
        }
    }

    private fun speakText(text: String) {
        if (!isTtsInitialized || tts == null) return
        stop()
        checkBluetoothAudioRouting()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "laprri_voice_${System.currentTimeMillis()}")
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
        }
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "laprri_voice_${System.currentTimeMillis()}")
    }

    private fun releaseMediaPlayer() {
        try {
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (_: Exception) {}
    }

    fun stop() {
        try {
            tts?.stop()
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
            releaseMediaPlayer()
        } catch (_: Exception) {}
        _isSpeaking.value = false
    }

    fun shutdown() {
        stop()
        mainHandler.removeCallbacksAndMessages(null)
        if (isReceiverRegistered) {
            try {
                context.unregisterReceiver(bluetoothReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        try {
            if (bluetoothHeadset != null && bluetoothAdapter != null) {
                bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HEADSET, bluetoothHeadset)
            }
        } catch (_: Exception) {}
        try {
            speechRecognizer?.destroy()
            speechRecognizer = null
        } catch (_: Exception) {}
        tts?.shutdown()
        tts = null
        isTtsInitialized = false
        onBluetoothDisconnected()
    }
}
