package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.model.AppInfo
import com.example.model.LaprriLanguage
import com.example.ui.theme.MyApplicationTheme
import com.example.util.LaprriVoiceManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                LaprriLiveWallpaperApp()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LaprriLiveWallpaperApp() {
    val context = LocalContext.current
    var is3DLoading by remember { mutableStateOf(true) }
    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var showControlsOverlay by remember { mutableStateOf(true) }
    var showAccessSettingsSheet by remember { mutableStateOf(false) }
    var appSearchQuery by remember { mutableStateOf("") }

    val voiceManager = remember { LaprriVoiceManager(context) }
    val isSpeaking by voiceManager.isSpeaking.collectAsState()
    val isListening by voiceManager.isListening.collectAsState()
    val isBluetoothConnected by voiceManager.isBluetoothConnected.collectAsState()
    val bluetoothDeviceName by voiceManager.bluetoothDeviceName.collectAsState()
    val currentDialogue by voiceManager.currentDialogue.collectAsState()
    val isVoiceEnabled by voiceManager.isVoiceEnabled.collectAsState()
    val hasCustomAudio by voiceManager.hasCustomAudio.collectAsState()
    val currentLanguage by voiceManager.currentLanguage.collectAsState()

    // Access states & Installed apps
    val isPhoneAccessEnabled by voiceManager.isPhoneAccessEnabled.collectAsState()
    val pendingPermissionApp by voiceManager.pendingPermissionApp.collectAsState()
    val installedApps by voiceManager.installedApps.collectAsState()

    // Multiple Permission launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val recordAudioGranted = permissions[Manifest.permission.RECORD_AUDIO] ?: false
        voiceManager.setPermissionGranted(recordAudioGranted)
        voiceManager.checkBluetoothAudioRouting()
        voiceManager.loadInstalledApps()
    }

    LaunchedEffect(Unit) {
        val permissionsToRequest = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionsToRequest.add(Manifest.permission.READ_MEDIA_IMAGES)
            permissionsToRequest.add(Manifest.permission.READ_MEDIA_VIDEO)
        }

        val missingPermissions = permissionsToRequest.filter { perm ->
            ContextCompat.checkSelfPermission(context, perm) != PackageManager.PERMISSION_GRANTED
        }

        if (missingPermissions.isEmpty()) {
            voiceManager.setPermissionGranted(true)
        } else {
            permissionsLauncher.launch(permissionsToRequest.toTypedArray())
        }
        voiceManager.loadInstalledApps()
    }

    // Audio Picker for custom voice / recording
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            voiceManager.addCustomAudioClip(uri, "My Custom Voice Note")
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            voiceManager.shutdown()
        }
    }

    // Live wallpaper HTML: Pure Pitch Black background (#000000), seamless auto-spin loop, touch pass-through & full animated pose
    val embedHtml = remember {
        """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
            <style>
                * {
                    box-sizing: border-box;
                    margin: 0;
                    padding: 0;
                    user-select: none;
                    -webkit-user-select: none;
                }
                html, body {
                    width: 100%;
                    height: 100%;
                    background-color: #000000 !important;
                    background: #000000 !important;
                    overflow: hidden;
                    touch-action: none;
                    pointer-events: none;
                }
                .sketchfab-embed-wrapper {
                    width: 100%;
                    height: 100%;
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: #000000 !important;
                    background: #000000 !important;
                    pointer-events: none;
                }
                #api-frame {
                    width: 100%;
                    height: 100%;
                    border: 0;
                    display: block;
                    background-color: #000000 !important;
                    background: #000000 !important;
                    pointer-events: none;
                }
            </style>
            <script type="text/javascript" src="https://static.sketchfab.com/api/sketchfab-viewer-1.12.1.js"></script>
        </head>
        <body>
            <div class="sketchfab-embed-wrapper">
                <iframe id="api-frame" title="Laprri 3D Animated" frameborder="0" allowfullscreen mozallowfullscreen="true" webkitallowfullscreen="true" allow="autoplay; fullscreen; xr-spatial-tracking" xr-spatial-tracking execution-while-out-of-viewport execution-while-not-rendered web-share src="https://sketchfab.com/models/6dbe3e3dc6704a36bb3acef80b0bc5e4/embed?autostart=1&autospin=0.35&preload=1&transparent=1&ui_animations=1&ui_controls=0&ui_infos=0&ui_watermark=0&ui_theme=dark&ui_hint=0"></iframe>
            </div>
            <script type="text/javascript">
                function initViewer() {
                    var iframe = document.getElementById('api-frame');
                    var version = '1.12.1';
                    var client = new Sketchfab(version, iframe);

                    client.init('6dbe3e3dc6704a36bb3acef80b0bc5e4', {
                        success: function onSuccess(api) {
                            api.start(function() {
                                api.addEventListener('viewerready', function() {
                                    api.setBackground({ color: [0, 0, 0, 1] }, function() {});
                                    api.setFov(45, function() {});
                                    api.getAnimations(function(err, animations) {
                                        if (!err && animations && animations.length > 0) {
                                            api.setCurrentAnimationByUID(animations[0].uid, function() {
                                                api.play(function() {});
                                            });
                                        }
                                    });
                                });
                            });
                        },
                        error: function onError() {},
                        autostart: 1,
                        autospin: 0.35,
                        preload: 1,
                        transparent: 1,
                        ui_animations: 0,
                        ui_controls: 0,
                        ui_infos: 0,
                        ui_watermark: 0,
                        ui_theme: 'dark',
                        ui_hint: 0
                    });
                }
                document.addEventListener('DOMContentLoaded', initViewer);
            </script>
        </body>
        </html>
        """.trimIndent()
    }

    // Sound wave animations
    val infiniteTransition = rememberInfiniteTransition(label = "voice_wave")
    val waveHeight1 by infiniteTransition.animateFloat(
        initialValue = 6f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            animation = tween(380, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w1"
    )
    val waveHeight2 by infiniteTransition.animateFloat(
        initialValue = 18f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(460, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w2"
    )
    val waveHeight3 by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 28f,
        animationSpec = infiniteRepeatable(
            animation = tween(320, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "w3"
    )
    val listeningPulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                showControlsOverlay = !showControlsOverlay
            }
    ) {
        // Pure Pitch Black 3D Animated Live Wallpaper
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(android.graphics.Color.BLACK)
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        loadWithOverviewMode = true
                        useWideViewPort = true
                        builtInZoomControls = false
                        displayZoomControls = false
                        allowFileAccess = true
                        allowContentAccess = true
                        setSupportZoom(false)
                        databaseEnabled = true
                        cacheMode = WebSettings.LOAD_DEFAULT
                        mediaPlaybackRequiresUserGesture = false
                    }
                    webViewClient = object : WebViewClient() {
                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            is3DLoading = true
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            is3DLoading = false
                        }

                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            request: WebResourceRequest?
                        ): Boolean {
                            return false
                        }
                    }
                    webChromeClient = WebChromeClient()
                    loadDataWithBaseURL("https://sketchfab.com", embedHtml, "text/html", "UTF-8", null)
                    webViewInstance = this
                    setOnTouchListener { _, _ -> false }
                }
            }
        )

        // Loading Indicator Overlay
        if (is3DLoading) {
            Surface(
                color = Color(0xEB000000),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.align(Alignment.Center)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(
                        color = Color(0xFF2DD4BF),
                        modifier = Modifier.size(36.dp),
                        strokeWidth = 3.dp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Loading Laprri 3D Wallpaper...",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        // Top Minimalist Controls Bar
        AnimatedVisibility(
            visible = showControlsOverlay,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Title Pill
                Surface(
                    color = Color(0xCC0A0A0A),
                    shape = RoundedCornerShape(20.dp),
                    shadowElevation = 6.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSpeaking) Color(0xFF34D399)
                                    else if (isListening) Color(0xFF2DD4BF).copy(alpha = listeningPulseAlpha)
                                    else Color(0xFF71717A)
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Laprri",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "• ${currentLanguage.nativeName}",
                            color = Color(0xFF2DD4BF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // 3-Language Switcher Button (Gujarati, Hindi, English)
                    Surface(
                        color = Color(0xFF0F766E),
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 6.dp,
                        modifier = Modifier.clickable {
                            val nextLang = when (currentLanguage) {
                                LaprriLanguage.GUJARATI -> LaprriLanguage.HINDI
                                LaprriLanguage.HINDI -> LaprriLanguage.ENGLISH
                                LaprriLanguage.ENGLISH -> LaprriLanguage.GUJARATI
                            }
                            voiceManager.setLanguage(nextLang, notifyUser = true)
                        }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Language,
                                contentDescription = "Switch Language",
                                tint = Color(0xFF5EEAD4),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = currentLanguage.nativeName,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // App Permissions & Access Control Button
                    Surface(
                        color = if (isPhoneAccessEnabled) Color(0xFF0F766E) else Color(0xCC27272A),
                        shape = CircleShape,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(36.dp)
                    ) {
                        IconButton(
                            onClick = {
                                voiceManager.loadInstalledApps()
                                showAccessSettingsSheet = true
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "App Permissions Manager",
                                tint = if (isPhoneAccessEnabled) Color(0xFF5EEAD4) else Color(0xFFA1A1AA),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Bluetooth Status Indicator
                    Surface(
                        color = if (isBluetoothConnected) Color(0xFF2563EB) else Color(0xCC18181B),
                        shape = CircleShape,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(36.dp)
                    ) {
                        IconButton(
                            onClick = { voiceManager.checkBluetoothAudioRouting() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isBluetoothConnected) Icons.Default.BluetoothConnected else Icons.Default.Bluetooth,
                                contentDescription = "Bluetooth Status",
                                tint = if (isBluetoothConnected) Color.White else Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Upload/Choose Custom Voice File
                    Surface(
                        color = if (hasCustomAudio) Color(0xFF0D9488) else Color(0xCC18181B),
                        shape = CircleShape,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(36.dp)
                    ) {
                        IconButton(
                            onClick = { audioPickerLauncher.launch("audio/*") },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AudioFile,
                                contentDescription = "Add custom voice note",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Voice Mute/Unmute Toggle
                    Surface(
                        color = if (isVoiceEnabled) Color(0xFF0D9488) else Color(0xCC18181B),
                        shape = CircleShape,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(36.dp)
                    ) {
                        IconButton(
                            onClick = { voiceManager.toggleVoice() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isVoiceEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                contentDescription = "Toggle Voice",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Refresh Button
                    Surface(
                        color = Color(0xCC18181B),
                        shape = CircleShape,
                        shadowElevation = 6.dp,
                        modifier = Modifier.size(36.dp)
                    ) {
                        IconButton(
                            onClick = { webViewInstance?.reload() },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Reload",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }

        // Bottom Voice & Pending Permission Alert Cards
        AnimatedVisibility(
            visible = showControlsOverlay,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Interactive Pending Permission Prompt Card (When Laprri asks user in selected language)
                AnimatedVisibility(
                    visible = pendingPermissionApp != null,
                    enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                    exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val app = pendingPermissionApp
                    if (app != null) {
                        val promptText = when (currentLanguage) {
                            LaprriLanguage.GUJARATI -> "\"સર, ${app.appName} ની પરમિશન મારી પાસે નથી. શું હું આ એપની પરમિશન આપી દઉં?\""
                            LaprriLanguage.HINDI -> "\"सर, ${app.appName} की परमिशन मेरे पास नहीं है। क्या मैं इसकी परमिशन अलाउ कर दूँ?\""
                            LaprriLanguage.ENGLISH -> "\"Sir, I don't have permission for ${app.appName}. Should I grant permission for it?\""
                        }
                        val allowBtnText = when (currentLanguage) {
                            LaprriLanguage.GUJARATI -> "હા, આપી દો (Voice)"
                            LaprriLanguage.HINDI -> "हाँ, दे दो (Voice)"
                            LaprriLanguage.ENGLISH -> "Yes, Allow (Voice)"
                        }
                        val denyBtnText = when (currentLanguage) {
                            LaprriLanguage.GUJARATI -> "ના, રહેવા દો"
                            LaprriLanguage.HINDI -> "नहीं, मत दो"
                            LaprriLanguage.ENGLISH -> "No, Deny"
                        }

                        Surface(
                            color = Color(0xF01E1B4B),
                            shape = RoundedCornerShape(18.dp),
                            shadowElevation = 10.dp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Warning,
                                        contentDescription = "Permission Required",
                                        tint = Color(0xFFF59E0B),
                                        modifier = Modifier.size(22.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Permission Required: ${app.appName}",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = promptText,
                                    color = Color(0xFFC7D2FE),
                                    fontSize = 13.sp,
                                    lineHeight = 18.sp
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { voiceManager.confirmPendingPermission(true) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = "Allow",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = allowBtnText, fontSize = 12.sp)
                                    }
                                    OutlinedButton(
                                        onClick = { voiceManager.confirmPendingPermission(false) },
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Deny",
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(text = denyBtnText, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }

                // Voice Assistant Status Badge
                Surface(
                    color = if (isBluetoothConnected) Color(0xCC1D4ED8) else if (isPhoneAccessEnabled) Color(0xCC0D9488) else Color(0xCC3F3F46),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isBluetoothConnected) Icons.Default.BluetoothConnected else if (isPhoneAccessEnabled) Icons.Default.Hearing else Icons.Default.Security,
                            contentDescription = "Audio routing",
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBluetoothConnected) {
                                "🎧 Bluetooth Active: ${bluetoothDeviceName ?: "Headset"}"
                            } else if (isPhoneAccessEnabled) {
                                when (currentLanguage) {
                                    LaprriLanguage.GUJARATI -> "🎙️ લપરી: 'WhatsApp ખોલો' અથવા 'YouTube ચાલુ કરો' બોલો"
                                    LaprriLanguage.HINDI -> "🎙️ लपरी: 'WhatsApp खोलो' या 'YouTube चलाओ' बोलिए"
                                    LaprriLanguage.ENGLISH -> "🎙️ Laprri: Speak any app (e.g. 'Open WhatsApp')"
                                }
                            } else {
                                "🔒 Phone Access Disabled (Say 'Access On')"
                            },
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                // Laprri Response Card
                Surface(
                    color = Color(0xE6101010),
                    shape = RoundedCornerShape(20.dp),
                    shadowElevation = 8.dp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { voiceManager.triggerWakeResponse() }
                        .testTag("laprri_voice_card")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isSpeaking) Color(0xFF0D9488)
                                    else if (isBluetoothConnected) Color(0xFF1E40AF)
                                    else Color(0xFF27272A)
                                )
                        ) {
                            if (isSpeaking) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(waveHeight1.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(waveHeight2.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(3.dp)
                                            .height(waveHeight3.dp)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                    )
                                }
                            } else {
                                Icon(
                                    imageVector = if (isBluetoothConnected) Icons.Default.Bluetooth else if (hasCustomAudio) Icons.Default.Mic else Icons.Default.GraphicEq,
                                    contentDescription = "Voice",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Laprri",
                                    color = Color(0xFF2DD4BF),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                if (isSpeaking) {
                                    Text(
                                        text = "• Speaking",
                                        color = Color(0xFF34D399),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                } else if (isListening) {
                                    Text(
                                        text = if (isBluetoothConnected) "• BT Mic Listening" else "• Listening",
                                        color = if (isBluetoothConnected) Color(0xFF93C5FD) else Color(0xFF94A3B8),
                                        fontSize = 10.sp
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(1.dp))
                            Text(
                                text = currentDialogue,
                                color = Color.White,
                                fontSize = 12.sp,
                                maxLines = 2,
                                lineHeight = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Surface(
                            color = Color(0xFF0D9488),
                            shape = CircleShape,
                            modifier = Modifier.size(34.dp)
                        ) {
                            IconButton(
                                onClick = { voiceManager.triggerWakeResponse() },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Play response",
                                    tint = Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Full Phone Apps Permissions & Voice Access Sheet
        if (showAccessSettingsSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAccessSettingsSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
                containerColor = Color(0xFF18181B)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(bottom = 32.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Laprri Settings & Permissions",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "3 Languages • Voice Launcher • Permissions",
                                color = Color(0xFF94A3B8),
                                fontSize = 12.sp
                            )
                        }
                        IconButton(onClick = { showAccessSettingsSheet = false }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Language Selector Card (Gujarati, Hindi, English)
                    Surface(
                        color = Color(0xFF27272A),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Language,
                                    contentDescription = "Language",
                                    tint = Color(0xFF2DD4BF),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Choose Voice Language / ભાષા / भाषा",
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                LaprriLanguage.entries.forEach { lang ->
                                    val isSelected = currentLanguage == lang
                                    Surface(
                                        color = if (isSelected) Color(0xFF0D9488) else Color(0xFF18181B),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier
                                            .weight(1f)
                                            .clickable { voiceManager.setLanguage(lang, notifyUser = true) }
                                            .then(
                                                if (isSelected) Modifier.border(1.5.dp, Color(0xFF5EEAD4), RoundedCornerShape(10.dp))
                                                else Modifier
                                            )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(vertical = 10.dp),
                                            horizontalAlignment = Alignment.CenterHorizontally
                                        ) {
                                            Text(
                                                text = lang.nativeName,
                                                color = if (isSelected) Color.White else Color(0xFFCBD5E1),
                                                fontSize = 13.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                            )
                                            Text(
                                                text = lang.displayName,
                                                color = if (isSelected) Color(0xFFCCFBF1) else Color(0xFF71717A),
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Master Phone Access Switch
                    Surface(
                        color = Color(0xFF27272A),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Security,
                                    contentDescription = "Master Access",
                                    tint = if (isPhoneAccessEnabled) Color(0xFF2DD4BF) else Color(0xFF71717A),
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "Master Phone Voice Access",
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isPhoneAccessEnabled) "ON (Voice commands active)" else "OFF (All commands blocked)",
                                        color = if (isPhoneAccessEnabled) Color(0xFF2DD4BF) else Color(0xFFEF4444),
                                        fontSize = 11.sp
                                    )
                                }
                            }
                            Switch(
                                checked = isPhoneAccessEnabled,
                                onCheckedChange = { voiceManager.setPhoneAccessEnabled(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF0D9488)
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Bulk Permission Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { voiceManager.grantAllPermissions() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0D9488)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.LockOpen,
                                contentDescription = "Allow All",
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Allow All Apps", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = { voiceManager.revokeAllPermissions() },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFEF4444)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Security,
                                contentDescription = "Revoke All",
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Revoke All", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Search Installed Apps
                    OutlinedTextField(
                        value = appSearchQuery,
                        onValueChange = { appSearchQuery = it },
                        placeholder = { Text("Search installed apps...", color = Color(0xFF71717A), fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = Color(0xFF94A3B8),
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (appSearchQuery.isNotEmpty()) {
                                IconButton(onClick = { appSearchQuery = "" }) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = Color(0xFF94A3B8),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF2DD4BF),
                            unfocusedBorderColor = Color(0xFF3F3F46),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    val filteredApps = remember(installedApps, appSearchQuery) {
                        if (appSearchQuery.isBlank()) installedApps
                        else installedApps.filter {
                            it.appName.contains(appSearchQuery, ignoreCase = true) ||
                            it.packageName.contains(appSearchQuery, ignoreCase = true)
                        }
                    }

                    Text(
                        text = "Phone Apps (${filteredApps.size}):",
                        color = Color(0xFFCBD5E1),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    // Installed Apps List
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 240.dp)
                    ) {
                        items(filteredApps, key = { it.packageName }) { app ->
                            AppPermissionRowItem(
                                app = app,
                                isMasterEnabled = isPhoneAccessEnabled,
                                onToggle = { voiceManager.toggleAppPermission(app) }
                            )
                            HorizontalDivider(color = Color(0xFF27272A))
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        color = Color(0xFF0F172A),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                text = "🗣️ Voice Commands (3 Languages):",
                                color = Color(0xFF38BDF8),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(3.dp))
                            Text(
                                text = "• ગુજરાતી: \"Laprri Gujarati ma bolo\", \"WhatsApp ખોલો\", \"પરમિશન હટાવો\"\n• हिन्दी: \"Laprri Hindi me bolo\", \"WhatsApp खोलो\", \"परमिशन हटा दो\"\n• English: \"Laprri speak in English\", \"Open WhatsApp\", \"Remove permission\"",
                                color = Color(0xFF94A3B8),
                                fontSize = 10.5.sp,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AppPermissionRowItem(
    app: AppInfo,
    isMasterEnabled: Boolean,
    onToggle: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Apps,
                contentDescription = app.appName,
                tint = if (app.isAllowed && isMasterEnabled) Color(0xFF2DD4BF) else Color(0xFF71717A),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = app.appName,
                    color = if (isMasterEnabled) Color.White else Color(0xFF71717A),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = if (app.isAllowed) "Allowed (Voice launch active)" else "Permission needed",
                    color = if (app.isAllowed) Color(0xFF34D399) else Color(0xFF94A3B8),
                    fontSize = 10.sp
                )
            }
        }
        Switch(
            checked = app.isAllowed,
            enabled = isMasterEnabled,
            onCheckedChange = { onToggle() },
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF0D9488)
            )
        )
    }
}
